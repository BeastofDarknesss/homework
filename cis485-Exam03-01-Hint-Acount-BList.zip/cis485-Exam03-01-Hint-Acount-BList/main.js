
const getJSONString = function(obj) { return JSON.stringify(obj, null, 2);}
function isNumber(value)
{
  value=value.trim();
  if(value=="") return false;
  else if (isNaN(value)) return false;
	return true;
}

var express = require ('express'); 
var app = express(); 
app.set('view engine', 'ejs');
app.use(express.static("public"));
app.use(express.urlencoded({extended: false}));
app.use(express.json());

app.get ("/", function (req,res) 
{
  res.render ( "gradestats",{list:"",alist:"",blist:"",acount:""});
} );
	
app.post('/', function(req, res)
{
   var alist=[],blist=[],clist=[],dlist=[],flist=[];
   let choice=req.body["choice"];
   let list=req.body.list;
   console.log("body="+getJSONString(req.body));
   if(choice=="Clear")     res.render ( "grades",{list:"",alist:""});
   else if(choice=="Enter")
   {
      console.log("list="+list);
      list=""+list;
      var list2=list.split(" "),list3=[],alist=[];
      console.log("list"+list)

      for(var i=0;i<list2.length;i++)//Remove Empty Elements
          if(list2[i]!=" "&&list2[i]!="") list3.push(list2[i].trim());
      console.log("list3="+list3.toString());
      
      for(var i=0;i<list3.length;i++)
      {
          if(parseFloat(list3[i])>=90 ) alist.push(parseFloat(list3[i])); 
          else if(parseFloat(list3[i])>=80 ) blist.push(parseFloat(list3[i])); 
      }
    
     


      var alen=alist.length;

      alist=alist.join(" ");
      blist=blist.join(" ");

      res.render ( "gradestats",{list:list,alist:alist,blist:blist,acount:alen});
   }

});
app.listen(3000 , function () {
	console.log ("server is listening!!!");
} );
